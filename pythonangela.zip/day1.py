
print("Hello world!")

#there is concept of taking inputs through the input function
input("enter a letter : "); #takes in parameter as the string that you want user to see

#in python indentation is very important blocks decided using the indentation only if wrong then "indentation error arises"

print("hello " + input("what is your name? ")); # '+' acts a concatenation
#above line similar that you make a variable to take in name in a variable and use that to print it

# comment done using the '#' symbol

#variables created directly without mentioning the type ... auto handled
#though not mentioning of type but it is also not weakly typed rather strongly typed as interepeter internally maintains the type and the 

#naming of the variables is same generic rules, dont use keyword name, dont start with numbers, no special character except _ etc.abs

#on mispelling you get a "name error"