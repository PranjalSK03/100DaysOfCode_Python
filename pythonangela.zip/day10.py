#function can return values too

#if a return statement executed beyond that nothing will be executed


def format_names(first, last):
  """ A function to append first and last name.
  Also this function makes them Camel cased"""
  #docstring above is for decribing function must be written just below the function declaration i.e as its first line

  if first == "" or last == "":
    return
  #using inbuilt function called title()
  return (first + " " + last).title()


first_name = input("Your first name: ")
last_name = input("Your last name: ")

returned_string = format_names(first_name, last_name)
if (returned_string):
  print(returned_string)
else:
  print("something went wrong")

# """  """  - these are called docstrings can write multilined content using enters and all they can be used to describe function so where they are called when you just point over the function one can see the function description.

#they can be used to document functions as done above

#and as multiline commenting if used directly without assiging it to any variable e.g.

"""
hello this is a comment.

"""
