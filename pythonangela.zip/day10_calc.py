import replit

logo = """
 _____________________
|  _________________  |
| | Pythonista   0. | |  .----------------.  .----------------.  .----------------.  .----------------. 
| |_________________| | | .--------------. || .--------------. || .--------------. || .--------------. |
|  ___ ___ ___   ___  | | |     ______   | || |      __      | || |   _____      | || |     ______   | |
| | 7 | 8 | 9 | | + | | | |   .' ___  |  | || |     /  \     | || |  |_   _|     | || |   .' ___  |  | |
| |___|___|___| |___| | | |  / .'   \_|  | || |    / /\ \    | || |    | |       | || |  / .'   \_|  | |
| | 4 | 5 | 6 | | - | | | |  | |         | || |   / ____ \   | || |    | |   _   | || |  | |         | |
| |___|___|___| |___| | | |  \ `.___.'\  | || | _/ /    \ \_ | || |   _| |__/ |  | || |  \ `.___.'\  | |
| | 1 | 2 | 3 | | x | | | |   `._____.'  | || ||____|  |____|| || |  |________|  | || |   `._____.'  | |
| |___|___|___| |___| | | |              | || |              | || |              | || |              | |
| | . | 0 | = | | / | | | '--------------' || '--------------' || '--------------' || '--------------' |
| |___|___|___| |___| |  '----------------'  '----------------'  '----------------'  '----------------' 
|_____________________|
"""

def add(num1, num2):
  """ function to add two nos. """
  return num1 + num2;

def sub(num1, num2):
  """ function to subtract two nos. """
  return num1 - num2;

def mult(num1, num2):
  """ function to multiply two nos. """
  return num1 * num2;

def div(num1, num2):
  """ function to divide two nos. """
  return num1 / num2;


operator_dict = {
  "+": add,
  "-": sub,
  "*": mult,
  "/": div,
}

print(logo);

choice = "y";
result = "";
num1_input_flag = True;
num1 = 0;
num2 = 0;

while(choice == "y"):
  
  if(num1_input_flag == True):
    num1 = float(input("enter the first number : "));
    for key in operator_dict:
      print(key);
      
  operator = input("enter your operator choice : ");

  num2 = float(input("enter the second number : "));


  for key in operator_dict:
    if key == operator:
      result = operator_dict[operator](num1, num2);

  if result == "":
    print("you entered a invalid operator so try again");
    input("Press any key to restart");
    replit.clear();
    continue;
  else:
    print(f"{num1} {operator} {num2} = {result}")

  choice = input(f"Press 'y' if you want to continue calculating with {result}, or 'n' if want to start a new calculation : ").lower();

  if(choice == 'y'):
    num1 = result;
    num1_input_flag = False;
  elif(choice == 'n'):
    num1_input_flag = True;
    replit.clear();
    choice = 'y';
  else:
    print("you entered a choice");
    input("Press any key to restart");
    replit.clear();

  resutl = ""