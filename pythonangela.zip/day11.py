from day11_art import logo
import replit
import random
import time
import sys

cards = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
card_points = {
  '2': 2,
  '3': 3,
  '4': 4,
  '5': 5,
  '6': 6,
  '7': 7,
  '8': 8,
  '9': 9,
  '10': 10,
  'J': 10,
  'Q': 10,
  'K': 10
}




def func_player_choice():
  player_choice = input("Do you want to play a game of Blackjack? Type 'y' or 'n': ").lower();
  if(player_choice == 'n'):
    return False;
  elif(player_choice == 'y'):
    return True;
  else:
    print("you entered a wrong choice! try again");
    time.sleep(4)
    sys.exit(-1)

def continue_next_round():
  player_choice = input("Type 'y' to get another card, type 'n' to pass: ")
  if(player_choice == 'n'):
    return False;
  elif(player_choice == 'y'):
    return True;
  else:
    print("\n \n You entered a wrong choice!");
    time.sleep(4)
    sys.exit(-1)


def get_random_card():
  return cards[int(random.random()*(len(cards)-1))]

def append_cards_list(list, times):
  for i in range(times):
    list.append(get_random_card())

def calculate_score(list):
  sum = 0  
  for i in list:
    if i in card_points:
      sum += card_points[i]
    elif (sum+11) < 21:
      sum += 11 #value of A = 11
    else:
      sum += 1  #valur of A = 1
  return sum
      
def print_final_scores(random_card_player, player_points, random_card_dealer, dealer_points):
  print("\t Your final hand :", random_card_player, "final score :", player_points)
  print("\t Computer's final hand :", random_card_dealer, "final score :", dealer_points)
  
  
while(func_player_choice()):

  random_card_player = []
  random_card_dealer = []
  
  replit.clear();
  print(logo);
  append_cards_list(random_card_player, 2)
  append_cards_list(random_card_dealer, 2)

  player_points = calculate_score(random_card_player);
  dealer_points = calculate_score(random_card_dealer);

  print("\t Your card :", random_card_player, "current score :", player_points)
  print("\t Computer's first card :", random_card_dealer[0])

  decision_continue = continue_next_round()
  while(decision_continue):

    if len(random_card_dealer) == len(random_card_player):
      append_cards_list(random_card_player, 1)
    else:
      append_cards_list(random_card_player, 1)
      append_cards_list(random_card_dealer, 1)

    player_points = calculate_score(random_card_player);
    dealer_points = calculate_score(random_card_dealer);
  
    print("\t Your card :", random_card_player, "current score :", player_points)
    print("\t Computer's first card :", random_card_dealer[0])

    if player_points > 21:
      break;
    
    decision_continue = continue_next_round()

  # a final hand drawn by computer if wanted
  while dealer_points < 17:
    append_cards_list(random_card_dealer, 1)
    dealer_points = calculate_score(random_card_dealer);

  
  print_final_scores(random_card_player, player_points, random_card_dealer, dealer_points)
  if player_points > 21 and decision_continue:
    print("You went over! You lose 😤")
  elif player_points > 21:
    print("You loose! 😤")
  elif player_points == dealer_points:
    print("Draw 🙃")
  else:
    print("You won! 😁")
      
    
  
  