
#DATA TYPES :-
#some of the data types are:- Int, Float, Strings, Boolean

#-------------------------------------------------------------------

#Strings - array of characters
#for strings use "", '' , ''' '''
print(type("Hello"))
print("Hello"[2]); # 0 based indexing
print(type("Hello"[3])); 
#for two strings concatentaion easily done using the +
print("123" + "54")

#-------------------------------------------------------------------

#Integer
print(123 + 54, " ---> the type of no. is : ", type(123 + 54)) #see that here normal addition happens with use of + symbol
#one can make the large nos more understandable (use of the _ instead of commas)
print(123_432 , "is equivalent to", 123432);

#-------------------------------------------------------------------

#float - floating point number (as the decimal place can float around among nos.)
print(3.14," ---> the type of no. is : ",type(3.14))
print(345_567.123)#see the comma can be seen here

#-------------------------------------------------------------------

#Boolean - True or False
a = True
b = False
if(a == b):
  print("Boolean don't exists")
else:
  print("Boolean exists")
  print(a, " ---> the type of the variable is : ", type(a))

#-------------------------------------------------------------------

#length function is only for the length of arrays and strings

#-------------------------------------------------------------------

#the input one takes from console is in given in codes as a string and no other type (uncomment the below code)
# a = input("a :")
# b = input("b :")
# print(a+b);


#one can't concatnate the string with any other data-type using the '+'' symbol

#-------------------------------------------------------------------

#to see type use the type() function - used above
# num = 7
# print("hello " + num); #this will be "type error"

#solution is type-casting
num = 7
num_str = str(num);
print("hello " + num_str);
print("type of the  num_str is : ", type(num_str))
#similarly type-casting can be done to integer and to float etc.

#-------------------------------------------------------------------

#mathematical operators in python :-
# +, -, /, +, **(exponent)
# //, +=, -=, /=, *=

#division always results output in floating point data type
#but we have a floor division too it floors off the value in floating point
print("use of the floor Division", 8 // 3)
#Priority :-
#()
#**
#* /
#+ -

#-------------------------------------------------------------------

#python has a math libarary too:
# round() - parameters as no. to round off and the no. of place till one wants to round {optional}
print("use of the round off method ", round(8/3))
print("use of round off with second parameter too ", round(8/3, 3))

#-------------------------------------------------------------------

#concept of fstrings - normally to append different data types to string one need to use type conversion but it is too inconvinient so use fstrings -> simply use 'f' before a string

a = 5;
b = 6.7;
c = False;
fstring = f"hello this is {a}, {b} and {c}";
print(fstring)
print(fstring[14])


#-------------------------------------------------------------------

#there is a format function - return the given no. in the format specified

fl_no = 3.14123
print(f"Here we use the format function on {fl_no} to display upto 2 decimal place only : ",format(fl_no, '.2f'))

#formatting different from rounding as in formatting its how we want to display rather than being a mathematical operation

#-------------------------------------------------------------------