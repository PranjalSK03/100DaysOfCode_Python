
#use of if-else -> indentation and ':' is important
height = input("enter your height in cm : ");

if int(height) > 180:
  print("you are tall")
else:
  print("you are not that tall")

#-----------------------------------------------------------

#the comparison operators are <, >, ==, >=, <=, !=

#-----------------------------------------------------------

# nesting of if-else can be done too

#for else if we use 'elif'
num = int(input("Enter a number : "));

if num < 0:
  print("it is a negative number")
elif num > 0:
  print("it is a positive number")
else:
  print("the number is 0")


#-----------------------------------------------------------

#using the logical operators in the python 
#and, or, not
#used to combine two conditions at a time, 
#'not' is used over a single operand only.

#-----------------------------------------------------------
name = input("Enter your name : ");
letter = input("enter a letter : ");
print(f"Here is the count of {letter} in {name} is -> ", name.count("l")) #a function to count something in something
