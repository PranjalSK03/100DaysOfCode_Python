#RANDOMIZATION - it is the process of the getting a random information out.
#random is nondeterminstic as it is very difficult to determine the next sequence of steps from the current one.

#random numbers can be generated from the noise(in any form) which one gets from the nature

#NOTE - nature and real world is random, but the computer are deterministic so question how to get the random output out of them, thus its not possible to get the random outputs rather the developers have implemented the pseudorandom algos.

#named pseudo random as number generated only appears random but is not truly random 

#Pseudorandom number generators nothing but algorithms that take up the a seed(truly random number) and try to generate a pseudo random number. for same seed same number is generated. 

#There is a "period" for each pseudo random number - the time after which seed is reached and number starts to reapeat itself. Thus larger(length a seed) the seed the better for it to make it appear like random

import random #a module
# a module contains code for implementing a particular type or functionality make code more readable. Also in large project many different person of teams can work on different modules.

a = random.randint(5, 30); #for random integers only
print(a);

b = random.random(); # genrate a floating point between 0 an 1
print(b);
# to generate the value between two nos x < y just do b*(y-x) + x
c = int(b*(30-5) + 5); # result a floating point between 30 and 5
print(c);




#DATA STRUCTURES
#lists - [] - stack can be made from it
#deque - mainly used to make queues - list implements them
#tuple - ()
#sets - {}
#dictionary - {} - key object pairs - best for hashMaps




#Lists - []
#just like arrays the order maintained and there is direct access using the indexes
# 0 based indexing as the first item is the start and rest all are offsets from the start, so offset of first item is 0 

fruits = ["apple", "banana", "melon", "grapes"];#intialization
print(fruits);
print(fruits[2]); #accessing the 3rd element

#concept of negative indexing in python which means -1 for last element in the list, -2 for second last
print(fruits[-1]);

#one can manipulate data at an index too
fruits[1] = "cherry"; #manipulation
print(fruits);

# to append elements in the list use append() function
fruits.append("mango");
print(fruits);

#other important functions include insert(), remove(), pop(), extend(), clear(), sort(), cout(), reverse() etc.
#https://docs.python.org/3/tutorial/datastructures.html?highlight=lists

# there is a choice() function - it chooses random element out of a list
print(random.choice(fruits))




#Nested Lists - lists within lists - multidimensional array
vegetables = ["tomatoes", "potato", "pumpkin", "beans"];

eatables = [fruits, vegetables];

print(eatables);
print(eatables[1]);
print(eatables[1][2]);

