import random
#LOOPS
  #for
  #while
#NOTE - python has no do-while loop, but one can emulate it in while loop by keeping while true and in side its block keep the breaking the condition at last

#------------------------------------------------------------------

#for loop -
fruits = ["apple", "banana", "melon", "grapes"];
for fruit in fruits:
  print(fruit)

print("\n")

#------------------------------------------------------------------

#range function - range(a,b) - means all number from 1 to 10 excluding 10
for i in range(0, 10):
  print(i);

#in range function one can also specify by how much steps the addition should be done 

print("\nprinting nos at gap of 2: \n");
for i in range(0, 10, 2):
  print(i);

#------------------------------------------------------------------

#jumble up the letters -
string = "hello_how?113"
print(string)

list = list(string);
print(list);
random.shuffle(list); #shuffle() only shuffles up a list/tuple
print(list);
string = '#'.join(list); #joins(converts to string) the element of the list/tuple using the whaterver chareacters in the '' {here its '#'}
print(string)

#------------------------------------------------------------------

