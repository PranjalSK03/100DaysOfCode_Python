#while loop -
i = 0
while i < 10:
  print(i)
  i+=1

#functions - for code repetetions , redability, modularity
def my_function(): #definition
  print("Hello");
  print("Bye");

my_function() #call


#project code - 1 

# def turn_right():
#     turn_left();
#     turn_left();
#     turn_left();
    
# def face_east():
#     while not is_facing_north():
#         turn_left();
#     turn_right();

# face_east();
# while not at_goal():
#     while wall_on_right():
#         while wall_in_front():
#             turn_left()
#         move()
#     turn_right();
#     if not at_goal():
#         move();



 #project code - 2

# def turn_right():
#     turn_left();
#     turn_left();
#     turn_left();
    
# while front_is_clear():
#     move();

    
# while not at_goal():
#     if right_is_clear():
#         turn_right();
#         move();
#     elif front_is_clear():
#         move();
#     else:
#         turn_left();
    