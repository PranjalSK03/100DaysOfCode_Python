import random
from replit import clear #to clear screen after every guess
from day7_words import word_list 
from day7_visuals import stages, logo

def display_string(string_list):
  for i in string_list:
    print(i, end = " ");
  print("\n")

print(logo);

the_word = random.choice(word_list);
print(the_word);

count_of_characters = len(the_word);

string_state = [];
for i in range(0,count_of_characters):
  string_state.append("_");


i = len(stages)-1;


while True:
  
  flag_guess_correct = False;
  user_entered_char = input("\nGuess a letter: ").lower();
  clear(); #to clear screen after every guess
  
  for j in range(0, len(the_word)):
    if string_state[j] == user_entered_char:
      print("You have already guessed", user_entered_char);
      flag_guess_correct = True
      break;
    if the_word[j] == user_entered_char:
      flag_guess_correct = True
      string_state[j] = user_entered_char;
      count_of_characters -= 1;

  
  if flag_guess_correct == False:
    print(f"You guessed {user_entered_char}, that's not the word. You lose a life");
    display_string(string_state);
    i -= 1;
    if i == 0:
      print("You loose.");
      print(f"The word was: {the_word}");
      print("\n", stages[i]);
      break;
  else:
    display_string(string_state);
    if count_of_characters == 0:
      print("You win.")
      print("\n", stages[i]);
      break;
    
  print("\n", stages[i]);

  
    
    
  
  
    