#functions with parameter
# the formal parameters 
# the actual parameters

#argument is the value of the parameter , while parameter is the name of the value

def multiply(num1, num2):
  prod = num1 * num2;
  print("the product of the numbers are: ", prod);

multiply(8, 6);

#8,6 are arguments respectively
#the num1, num2 are parameters respectively



def add(num1, num2):
  sum = num1 + num2;
  print("the sum is", sum);


number1 = int(input("First no. to add: "));
number2 = int(input("Second no. to add: "));
add(number1, number2);

#there is positional arguments (order decided what value the parameters get)

#ther is also keyword arguments where order not matter rather keyword is used to decide value by assigning them while passing the values

def func_print(name, location):
  print(f"Hi i am {name}");
  print(f"i live in {location}")

person_name = input("Your name: ")
person_location = input("Where do you live? ")
func_print(location = person_location, name = person_name)
#thus we map argument to the keywords