from day8_caesar_cipher_art import logo
import sys

alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


def return_location(character):
  for i in range(0, len(alphabet)):
    if alphabet[i] == character:
      return i;

  return -1;


def caesar(text, shift):
  final_text = ""
  for i in range(0, len(text)):
    index_of_character = return_location(text[i])
    #instead one can use alpabet.index(index_of_character)
    if index_of_character == -1:
      print("illegal characters detected! Message must contain only alphabets");
      sys.exit(-1);

    final_text += alphabet[( index_of_character 
                            + shift)%len(alphabet)]

  return final_text;
  


#---------------------------------------------------------
print(logo)

to_go = "yes";

while to_go == "yes":
  choice = input("type 'encode' to encrypt, type 'decode' to decrypt:\n").lower();
  
  if choice == "encode":
    text = input("Type your message:\n").lower();
    shift = int(input("Type the shift number:\n"));
    print("Here is your encoded result: ", caesar(text, shift));
  
  elif choice == "decode":
    text = input("Type your message:\n").lower();
    shift = int(input("Type the shift number:\n"));
    print("Here is your dencoded result: ", caesar(text, shift*(-1)));
  
  else:
    print("Try again! wrong attempt");

  to_go = input("Type 'yes' if you want to go again. Otherwise type 'no'.\n").lower();

  if(not(to_go == 'yes' or to_go == 'no')):
    print("you entered a wrong choice!");
    sys.exit(-1);