#dicitonary - one can actually make key value pair using them
#{} - {key: value, ...} (declaration of the dicitionary)
#to access the dicinary key's value just use "dict_name[key]"

#for a single key there can be only single value associated with it.

personal_details = {
  "name": "Pranjal Singh Katiyar",
  "age": 20,
  "sex": "Male",
  "cgpa": 9.07
};

#accessing
print(personal_details["name"]);

#assiging new key value pairs
personal_details["Indian"] = True;
print(personal_details);

#reassiging/ updating
personal_details["age"] = 21;
print(personal_details);

#to clear a dicitonary 
personal_details = {};
print(personal_details);

#diffrent data structures(list, dictionary, tuple etc) can be nesteda

