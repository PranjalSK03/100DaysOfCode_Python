import replit

logo = '''
                         ___________
                         \         /
                          )_______(
                          |"""""""|_.-._,.---------.,_.-._
                          |       | | |               | | ''-.
                          |       |_| |_             _| |_..-'
                          |_______| '-' `'---------'` '-'
                          )"""""""(
                         /_________\\
                       .-------------.
                      /_______________\\
'''

print(logo);
print("Welcome to secret auction program.");

to_continue = "yes";
bidder_dict = {};



def find_maximum_bidder():
  max = 0;
  winner = 'none';
  
  for i in bidder_dict:
    if bidder_dict[i] > max:
      max = bidder_dict[i];
      winner = i;
      
  print(f"The winner is {winner} with a bid of ${bidder_dict[winner]}");



while to_continue == "yes":

  bidder_name = input("What is your name? ");
  bidder_val = int(input("What is you bid? $")) ;

  bidder_dict[bidder_name] = bidder_val;
  
  to_continue = input("Are there any other bidders? Type 'yes' or 'no'.\n").lower();

  
  if not((to_continue == "yes") or (to_continue == "no")):
    print("\nWrong choice !! \nplease redo the process \n");
    to_continue = "yes";
  else:
      replit.clear();
  
  if(to_continue == "no"):
    find_maximum_bidder();
    
  
  
